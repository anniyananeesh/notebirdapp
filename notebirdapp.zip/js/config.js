angular.module('starter.config', [])
.constant('REMOTE_HOST', 'http://localhost:3000/') //An IP when on production
.constant('GCM_SENDER_ID', '574597432927');